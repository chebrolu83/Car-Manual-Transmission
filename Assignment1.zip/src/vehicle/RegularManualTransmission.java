package vehicle;

/**
 * the Manual system with gears, speeds and status in a car .
 */
public class RegularManualTransmission implements ManualTransmission {
  private final int speed;
  private final int gear;
  String status;
  private final int l1;
  private final int h1;
  private final int l2;
  private final int h2;
  private final int l3;
  private final int h3;
  private final int l4;
  private final int h4;
  private final int l5;
  private final int h5;

  /**
   * Constructs manual transmission.
   *
   * @param l1 low speed for gear 1
   * @param h1 high speed for gear 1
   * @param l2 low speed for gear 2
   * @param h2 high speed for gear 2
   * @param l3 low speed for gear 3
   * @param h3 high speed for gear 3
   * @param l4 low speed for gear 4
   * @param h4 high speed for gear 4
   * @param l5 low speed for gear 5
   * @param h5 high speed for gear 5
   * @throws IllegalArgumentException if bound values are illegal
   */
  public RegularManualTransmission(int l1, int h1, int l2, int h2, int l3,
                                   int h3, int l4, int h4, int l5, int h5)
          throws IllegalArgumentException {

    this.l1 = l1;
    this.h1 = h1;
    this.l2 = l2;
    this.h2 = h2;
    this.l3 = l3;
    this.h3 = h3;
    this.l4 = l4;
    this.h4 = h4;
    this.l5 = l5;
    this.h5 = h5;

    this.speed = 0;
    this.gear = 1;
    this.status = "OK: everything is OK.";

    if (l1 != 0 || l1 > h1 || l2 > h2
            || l3 > h3 || l4 > h4 || l5 > h5) {
      throw new IllegalArgumentException("Each lower speed must be less "
              + "than or equal to its corresponding higher speed, "
              + "and the lower speed for the first gear must be 0.");
    }
    if (l2 <= l1 || l3 <= l2
            || l4 <= l3 || l5 <= l4) {
      throw new IllegalArgumentException("The lower speed of each gear must be strictly less than "
              + "the lower speed of the subsequent gear.");
    }
    if (l2 > h1 || l3 > h2
            || l4 > h3 || l5 > h4) {
      throw new IllegalArgumentException("The speed ranges of adjacent gears must overlap.");
    }
  }


  private RegularManualTransmission(int speed, int gear, String status, int l1, int h1, int l2,
                                    int h2, int l3, int h3, int l4, int h4, int l5, int h5) {

    this.l1 = 0;
    this.h1 = h1;
    this.l2 = l2;
    this.h2 = h2;
    this.l3 = l3;
    this.h3 = h3;
    this.l4 = l4;
    this.h4 = h4;
    this.l5 = l5;
    this.h5 = h5;

    this.speed = speed;
    this.gear = gear;
    this.status = status;

    if (l1 != 0 || l1 > h1 || l2 > h2
            || l3 > h3 || l4 > h4 || l5 > h5) {
      throw new IllegalArgumentException("Each lower speed must be less than or equal to its "
              + "corresponding higher speed, and the lower speed for the first gear must be 0.");
    }
    if (l2 <= l1 || l3 <= l2
            || l4 <= l3 || l5 <= l4) {
      throw new IllegalArgumentException("The lower speed of each gear must be strictly "
              + "less than the lower speed of the subsequent gear.");
    }
    if (l2 > h1 || l3 > h2
            || l4 > h3 || l5 > h4) {
      throw new IllegalArgumentException("The speed ranges of adjacent gears must overlap.");
    }
  }


  private void valid(int l1, int h1, int l2, int h2, int l3, int h3,
                     int l4, int h4, int l5, int h5) {
    if (l1 > h1 || l2 > h2 || l3 > h3 || l4 > h4 || l5 > h5) {
      throw new IllegalArgumentException("The lower gears must have smaller speed "
              + "limits than their corresponding higher gears.");
    } else if (h1 < l2 || h2 < l3 || h3 < l4 || h4 < l5) {
      throw new IllegalArgumentException("Gears have to overlap");
    } else if (l1 != 0) {
      throw new IllegalArgumentException("Lowest speed has to be 0");
    } else if (l1 >= l2 || l2 >= l3 || l3 >= l4 || l4 >= l5) {
      throw new IllegalArgumentException("Lower gears must have lower limits than next gears");
    }
  }

  @Override
  //gets the status
  public String getStatus() {
    return this.status;
  }

  @Override
  //gets the speed
  public int getSpeed() {
    return this.speed;
  }

  @Override
  //gets the gear
  public int getGear() {
    return this.gear;
  }


  //constructs a new object for speed
  private ManualTransmission object(int updateSpeed, String updateStatus) {
    return new RegularManualTransmission(updateSpeed, this.gear, updateStatus, this.l1, this.h1,
            this.l2, this.h2, this.l3, this.h3, this.l4, this.h4, this.l5, this.h5);
  }



  @Override
  //increases the speed without changing the gears
  public ManualTransmission increaseSpeed() {
    int updateSpeed = this.speed + 1;

    //checks each gear parameters
    switch (gear) {
      case 1:
        if (updateSpeed <= h1) {
          if (updateSpeed >= l2) {
            return object(updateSpeed, "OK: you may increase the gear.");
          } else {
            return object(updateSpeed, "OK: everything is OK.");
          }
        } break;
      case 2:
        if (updateSpeed <= h2) {
          if (updateSpeed >= l3) {
            return object(updateSpeed, "OK: you may increase the gear.");
          } else {
            return object(updateSpeed, "OK: everything is OK.");
          }
        } break;
      case 3: // gear is 3
        if (updateSpeed <= h3) {
          if (updateSpeed >= l4) {
            return object(updateSpeed, "OK: you may increase the gear.");
          } else {
            return object(updateSpeed, "OK: everything is OK.");
          }
        } break;
      case 4: // gear is 4
        if (updateSpeed <= h4) {
          if (updateSpeed >= l5) {
            return object(updateSpeed, "OK: you may increase the gear.");
          } else {
            return object(updateSpeed, "OK: everything is OK.");
          }
        } break;
      case 5: // gear is 5
        if (updateSpeed <= h5) {
          return object(updateSpeed, "OK: everything is OK.");
        } else {
          return object(this.speed, "Cannot increase speed. Reached maximum speed." );
        }
      default:
        return object(this.speed, "Cannot increase speed, increase gear first.");
    }
    return object(this.speed, "Cannot increase speed, increase gear first.");
  }


  @Override
  public ManualTransmission decreaseSpeed() {
    int updateSpeed = this.speed - 1;

    switch (gear) {
      case 1:
        if (updateSpeed >= l1) {
          return object(updateSpeed, "OK: everything is OK.");
        } else {
          return object(this.speed, "Cannot decrease speed. Reached minimum speed.");
        }
      case 2:
        if (updateSpeed >= l2) {
          if (updateSpeed <= h1) {
            return object(updateSpeed, "OK: you may decrease the gear.");
          } else {
            return object(updateSpeed, "OK: everything is OK." );
          }
        } break;
      case 3:
        if (updateSpeed >= l3) {
          if (updateSpeed <= h2) {
            return object(updateSpeed, "OK: you may decrease the gear.");
          } else {
            return object(updateSpeed, "OK: everything is OK." );
          }
        } break;
      case 4:
        if (updateSpeed >= l4) {
          if (updateSpeed <= h3) {
            return object(updateSpeed, "OK: you may decrease the gear.");
          } else {
            return object(updateSpeed, "OK: everything is OK." );
          }
        } break;

      case 5:
        if (updateSpeed >= l5) {
          if (updateSpeed <= h4) {
            return object(updateSpeed, "OK: you may decrease the gear.");
          } else {
            return object(updateSpeed, "OK: everything is OK." );
          }
        } break;

      default:
        return object(this.speed, "Cannot decrease speed, decrease gear first.");
    }
    return object(this.speed, "Cannot decrease speed, decrease gear first.");
  }

  //constructs a new object for speed
  private ManualTransmission objectGear(int updateGear, String updateStatus) {
    return new RegularManualTransmission(this.speed, updateGear, updateStatus, this.l1, this.h1,
            this.l2, this.h2, this.l3, this.h3, this.l4, this.h4, this.l5, this.h5);
  }

  @Override
  public ManualTransmission increaseGear() {
    int updateGear = this.gear + 1;
    switch (gear) {
      case 1:
        if (this.speed >= l2) {
          return objectGear(updateGear, "OK: everything is OK.");
        } else if (this.speed < l2) {
          return objectGear(this.gear, "Cannot increase gear, increase speed first.");
        } break;
      case 2:
        if (this.speed >= l3) {
          return objectGear(updateGear, "OK: everything is OK.");
        } else if (this.speed < l3) {
          return objectGear(this.gear,"Cannot increase gear, increase speed first.");
        } break;
      case 3:
        if (this.speed >= l4) {
          return objectGear(updateGear, "OK: everything is OK.");
        } else if (this.speed < l4) {
          return objectGear(this.gear,"Cannot increase gear, increase speed first.");
        } break;
      case 4: // gear is 4
        if (this.speed >= l5) {
          return objectGear(updateGear, "OK: everything is OK.");
        } else if (this.speed < l5) {
          return objectGear(this.gear, "Cannot increase gear, increase speed first.");
        } break;
      case 5: // gear is 5
        return objectGear(this.gear,"Cannot increase gear. Reached maximum gear." );
      default:
        return objectGear(this.gear, "Cannot increase gear, increase speed first.");
    }
    return this;
  }


  @Override
  public ManualTransmission decreaseGear() {
    int updateGear = this.gear - 1;

    switch (gear) {
      case 1:
        return objectGear(this.gear,"Cannot decrease gear. Reached minimum gear.");
      case 2:
        if (this.speed <= h1) {
          return objectGear(updateGear, "OK: everything is OK.");
        } else if (this.speed > h1) {
          return objectGear(this.gear, "Cannot decrease gear, decrease speed first.");
        } break;
      case 3:
        if (this.speed <= h2) {
          return objectGear(updateGear, "OK: everything is OK.");
        } else if (this.speed > h2) {
          return objectGear(this.gear, "Cannot decrease gear, decrease speed first.");
        } break;
      case 4: // gear is 4
        if (this.speed <= h3) {
          return objectGear(updateGear, "OK: everything is OK.");
        } else if (this.speed > h3) {
          return objectGear(this.gear, "Cannot decrease gear, decrease speed first.");
        } break;
      case 5: // gear is 5
        if (this.speed <= h4) {
          return objectGear(updateGear, "OK: everything is OK.");
        } else if (this.speed > h4) {
          return objectGear(this.gear, "Cannot decrease gear, decrease speed first.");
        } break;
      default:
        return objectGear(this.gear, "Cannot decrease gear, decrease speed first.");
    }
    return this;
  }

}

