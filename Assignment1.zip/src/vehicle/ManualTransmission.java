package vehicle;


/**
 * holds all methods for the RegularManualTransmission to implement.
 */
public interface ManualTransmission {


  public String getStatus();


  public int getSpeed();


  public int getGear();


  public ManualTransmission increaseSpeed();


  public ManualTransmission decreaseSpeed();


  public ManualTransmission increaseGear();


  public ManualTransmission decreaseGear();

}









