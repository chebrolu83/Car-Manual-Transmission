import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import vehicle.ManualTransmission;
import vehicle.RegularManualTransmission;


/**
 * Tests for RegularManualTransmission.
 */
public class RegularManualTransmissionTest {
  private ManualTransmission car;

  @Before
  public void setUp() {
    car = new RegularManualTransmission(0, 3, 2, 5, 5, 8, 7,10, 10, 13);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testOneFirstLimit() {
    this.setUp();
    ManualTransmission invalid;
    invalid = new RegularManualTransmission(1, 2, 1, 3, 3, 5, 4, 6, 6, 8);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testOverlap() {
    this.setUp();
    ManualTransmission invalid2;
    invalid2 = new RegularManualTransmission(0, 1, 3, 5, 7, 9, 11, 13, 15, 17);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testWrongBounds() {
    this.setUp();
    ManualTransmission invalid3;
    invalid3 = new RegularManualTransmission(0, 2, 1, 4, 2, 6, 1, 8, 0, 9);
  }

  @Test
  public void testStartingCond() {
    this.setUp();
    assertEquals(0, car.getSpeed());
    assertEquals(1, car.getGear());
    assertEquals("OK: everything is OK.", car.getStatus());
  }

  @Test
  public void testIncreaseSpeed() {
    this.setUp();
    car = car.increaseSpeed();
    assertEquals(1, car.getSpeed());
    assertEquals(1, car.getGear());
    assertEquals("OK: everything is OK.", car.getStatus());

    car = car.increaseSpeed(); // 2
    assertEquals(2, car.getSpeed());
    assertEquals(1, car.getGear());
    assertEquals("OK: you may increase the gear.", car.getStatus());

    car = car.increaseSpeed();
    car = car.increaseSpeed(); //speed 4, gear 1; should not happen
    assertEquals(3, car.getSpeed());
    assertEquals(1, car.getGear());
    assertEquals("Cannot increase speed, increase gear first.", car.getStatus());

    car = car.increaseGear(); //gear 2
    car = car.increaseSpeed(); //speed 4
    car = car.increaseSpeed(); //speed 5
    car = car.increaseGear(); //gear 3
    car = car.increaseSpeed(); //speed 6
    car = car.increaseSpeed(); //speed 7
    car = car.increaseSpeed(); //speed 8
    car = car.increaseGear();  //gear 4
    car = car.increaseSpeed(); //speed 9
    car = car.increaseSpeed(); //speed 10
    car = car.increaseGear(); //gear 5
    car = car.increaseSpeed(); //speed 11
    car = car.increaseSpeed(); //speed 12
    car = car.increaseSpeed(); //speed 13
    car = car.increaseSpeed();
    assertEquals(13, car.getSpeed());
    assertEquals(5, car.getGear());
    assertEquals("Cannot increase speed. Reached maximum speed.", car.getStatus());

    car = car.decreaseSpeed();
    assertEquals(12, car.getSpeed());
    assertEquals(5, car.getGear());
    assertEquals("OK: everything is OK.", car.getStatus());

  }


  @Test
  public void testDecreaseSpeed() {
    this.setUp();
    car = car.increaseSpeed();
    assertEquals(1, car.getSpeed());
    assertEquals(1, car.getGear());

    car = car.increaseSpeed(); // 2
    car = car.decreaseSpeed(); // 1
    assertEquals(1, car.getSpeed());
    assertEquals(1, car.getGear());
    assertEquals("OK: everything is OK.", car.getStatus());

    car = car.increaseSpeed(); // 2
    car = car.increaseSpeed(); // 3
    car = car.increaseGear(); // gear 2
    car = car.increaseSpeed(); // 4
    car = car.increaseSpeed(); // 5
    car = car.decreaseSpeed(); // 4
    assertEquals(4, car.getSpeed());
    assertEquals(2, car.getGear());
    assertEquals("OK: everything is OK.", car.getStatus());

    car = car.decreaseSpeed(); // 3
    car = car.decreaseSpeed(); // 2
    car = car.decreaseSpeed(); // 1
    car = car.decreaseSpeed(); // 0
    car = car.decreaseSpeed();
    assertEquals(2, car.getSpeed());
    assertEquals(2, car.getGear());
    assertEquals("Cannot decrease speed, decrease gear first.", car.getStatus());
  }


  @Test
  public void testIncreaseGear() {
    this.setUp();
    car = car.increaseGear();
    assertEquals(0, car.getSpeed());
    assertEquals(1, car.getGear());
    assertEquals("Cannot increase gear, increase speed first.", car.getStatus());


    car = car.increaseSpeed(); // 1
    car = car.increaseGear(); // 2
    assertEquals(1, car.getSpeed());
    assertEquals(1, car.getGear());
    assertEquals("Cannot increase gear, increase speed first.", car.getStatus());

    car = car.increaseSpeed(); // 2
    car = car.increaseSpeed(); // 3
    car = car.increaseGear(); // gear 2
    car = car.increaseSpeed(); // 4
    car = car.increaseSpeed(); // 5
    car = car.increaseGear(); // gear 3
    car = car.increaseSpeed(); // 6
    car = car.increaseGear(); //
    assertEquals(6, car.getSpeed());
    assertEquals(3, car.getGear());
    assertEquals("Cannot increase gear, increase speed first.", car.getStatus());


    car = car.increaseSpeed(); // 7
    car = car.increaseSpeed(); // 8
    car = car.increaseGear(); // gear 4
    car = car.increaseSpeed(); // 9
    assertEquals(9, car.getSpeed());
    assertEquals(4, car.getGear());
    assertEquals("OK: everything is OK.", car.getStatus());
    car = car.increaseSpeed();//10
    car = car.increaseGear();
    car = car.increaseGear();
    assertEquals("Cannot increase gear. Reached maximum gear.", car.getStatus());


  }

  @Test
  public void testDecreaseGear() {
    this.setUp();
    car = car.decreaseGear();
    assertEquals(0, car.getSpeed());
    assertEquals(1, car.getGear());
    assertEquals("Cannot decrease gear. Reached minimum gear.", car.getStatus());

    car = car.increaseSpeed(); // 1
    car = car.increaseSpeed(); // 2
    car = car.increaseSpeed(); // 3
    car = car.increaseGear(); // gear 2
    car = car.increaseSpeed(); // 4
    car = car.decreaseGear();
    assertEquals(4, car.getSpeed());
    assertEquals(2, car.getGear());
    assertEquals("Cannot decrease gear, decrease speed first.", car.getStatus());

    car = car.decreaseSpeed(); //3
    car = car.decreaseGear(); //gear 1
    assertEquals(3, car.getSpeed());
    assertEquals(1, car.getGear());
    assertEquals("OK: everything is OK.", car.getStatus());

    car = car.decreaseSpeed(); // 2
    car = car.decreaseSpeed(); // 1
    car = car.decreaseSpeed(); // 0
    car = car.decreaseSpeed();
    assertEquals("Cannot decrease speed. Reached minimum speed.", car.getStatus());


  }


}



